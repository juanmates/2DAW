package com.ejercicios.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ejercicios.modelo.Direccion;

public interface DireccionRepository extends JpaRepository<Direccion, Long>{

}
