package com.ejercicios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoBelenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoBelenApplication.class, args);
	}

}
