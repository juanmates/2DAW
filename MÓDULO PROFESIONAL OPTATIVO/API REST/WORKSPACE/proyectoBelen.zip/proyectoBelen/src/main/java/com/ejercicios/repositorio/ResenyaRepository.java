package com.ejercicios.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ejercicios.modelo.Resenya;

public interface ResenyaRepository extends JpaRepository<Resenya, Long>{

}
